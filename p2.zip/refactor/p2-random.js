/*
CIT 281 Project 2
Name: Jackson Feist
*/
// Returns a random number between min (inclusive) and max (exclusive)
function getRandomInteger(min, max) {
return Math.floor(Math.random() * (max - min) + min);
}
const alphabet = "abcdefghijklmnopqrstuvwxyz".split("");
let result = "";

//Gets random lowercase letter
function getRandomLetter() {
    return alphabet[getRandomInteger(1,alphabet.length-1)];
}

/*
for (let i = 0; i < getRandomInteger(5, 26); i++) {
result += getRandomLetter();
}
*/

//Gets random string of letters at random length between two bounds
function getRandomString(minLength, maxLength) {
    let res = "";
    for (let i = 0; i < getRandomInteger(minLength, maxLength + 1); i++) {
        res += getRandomLetter();
    }
    return res;
}

//Sorts a string by converting to array, sorting, the converting back to string
function getSortedString(string) {
    return string.split("").sort().join("");
}

console.log(getRandomString(10,20));
console.log(getSortedString(getRandomString(10,20)));

